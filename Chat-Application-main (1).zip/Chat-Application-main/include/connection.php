<?php

$con = mysqli_connect("localhost:3307", "root", "", "mychat") or die("Connection failed!");

?>